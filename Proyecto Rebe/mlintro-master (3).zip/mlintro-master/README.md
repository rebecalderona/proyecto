Introduccion a Machine Learning:
Curso dictado en ambiente academico, además del material instruccional contiene evaluaciones y multimedia no disponible en el repositorio

1. Tips para escribir codigo modular:
    a) Abstraer la logica del codigo fuente para mejorar la lectura de este
    b) Una funcion debe efectuar unicamente una actividad debidamente delimitada
    c) Evitar el codigo redundante
    d) En ciertas funciones el uso de nombres de variables arbitrarios puede ser mas efectivo
    e) Trate de usar hasta un maximo de 3 parametros por funcion