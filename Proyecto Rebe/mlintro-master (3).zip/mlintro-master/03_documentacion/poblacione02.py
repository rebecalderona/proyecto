def densidad_poblacional(poblacion, area):
    """ calcula la densidad poblacional de un area
    
    Argumentos:
    poblacion: int. La poblacion de un area
    area: int o float. Se aceptan unidades en kms o millas cuadradas
    
    Devuelve:
    densidad_poblacional: poblacion/area
    """
    return poblacion / area
