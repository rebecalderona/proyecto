def mascara_optimizacion(bordes):
    #encontrar mascara con area cercana al 50% de la imagen
    
    niveles_bordes = np.arrange(0.008, 0.1, 0.01)
    #0.008 es lo suficientemente bajo para detectar separacion
    #entre el objeto y el fondo cuando son del mismo color, tamaño y
    #si encaja en la mascara lo suficientemente cercano cuando los
    #colores son bien distintos. Ejemplo: si el borde...
    
    obtener_mascara = lambda niveles_bordes: ndi.binary_fill_holes(bordes > niveles_bordes)
    #....
    
    #limpiar mascara = eliminar pequeños espacios obtenidos en el fondo
    espacios_menores = range(1, 1000, 100)
    clean = lambda mascara, i:morfologia.eliminar_obj_pequenos(mascara, 1)
    #...
    return mask
    
    
    
